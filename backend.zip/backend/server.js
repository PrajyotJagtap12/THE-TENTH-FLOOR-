const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log("MongoDB connected"))
.catch(err => console.error("MongoDB connection error:", err));

// Define Review Schema
const reviewSchema = new mongoose.Schema({
    name: String,
    email: String,
    contact: String,
    review: String,
    rating: Number,
    createdAt: { type: Date, default: Date.now }
});

const Review = mongoose.model("Review", reviewSchema);

// Route to serve the review form
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
app.get("/hotelmenu", (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'hotelmenu.html'));
});

// Route to submit a review
app.post("/review", async (req, res) => {
    try {
        const { name, email, contact, review, rating } = req.body;
        const newReview = new Review({ name, email, contact, review, rating });
        await newReview.save();
        // Redirect to confirmation page after successful submission
        res.sendFile(path.join(__dirname, 'public', 'x.html'));
    } catch (error) {
        res.status(500).json({ error: "Error submitting review" });
    }
});

// Route to get all reviews (API endpoint)
app.get("/api/reviews", async (req, res) => {
    try {
        const reviews = await Review.find().sort({ createdAt: -1 });
        res.status(200).json(reviews);
    } catch (error) {
        res.status(500).json({ error: "Error fetching reviews" });
    }
});

// Start the server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));