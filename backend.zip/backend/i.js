const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log("MongoDB connected"))
.catch(err => console.error("MongoDB connection error:", err));

// Define Review Schema
const reviewSchema = new mongoose.Schema({
    name: String,
    email: String,
    contact: String,
    review: String,
    rating: Number,
    createdAt: { type: Date, default: Date.now }
});

const Review = mongoose.model("Review", reviewSchema);

// Define Booking Schema
const bookingSchema = new mongoose.Schema({
    name: { type: String, required: true },
    mobile: { type: String, required: true },
    tableNumber: { type: Number, required: true, min: 1, max: 10 },
    totalPeople: { type: Number, required: true, min: 1 },
    bookingTime: { type: Date, default: Date.now },
    status: { type: String, default: 'confirmed' }
});

const Booking = mongoose.model("Booking", bookingSchema);

// Route to serve the review form
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
app.get("/about", (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

app.get("/hotelmenu", (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'hotelmenu.html'));
});

// Route to submit a review
app.post("/review", async (req, res) => {
    try {
        const { name, email, contact, review, rating } = req.body;
        const newReview = new Review({ name, email, contact, review, rating });
        await newReview.save();
        // Redirect to confirmation page after successful submission
        res.sendFile(path.join(__dirname, 'public', 'x.html'));
    } catch (error) {
        res.status(500).json({ error: "Error submitting review" });
    }
});

// Route to get all reviews (API endpoint)
app.get("/api/reviews", async (req, res) => {
    try {
        const reviews = await Review.find().sort({ createdAt: -1 });
        res.status(200).json(reviews);
    } catch (error) {
        res.status(500).json({ error: "Error fetching reviews" });
    }
});

// Booking Routes
app.get("/bookings", (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'tablebooking.html'));
});
app.get("/reviewslist", (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'reviewslist.html'));
});

// API endpoint to book a table
app.post("/api/book", async (req, res) => {
    try {
        const { name, mobile, tableNumber, totalPeople } = req.body;
        
        // Validation
        if (!name || !mobile || !tableNumber || !totalPeople) {
            return res.status(400).json({ 
                success: false, 
                message: 'All fields are required' 
            });
        }
        
        const tableNum = parseInt(tableNumber);
        if (isNaN(tableNum)) {
            return res.status(400).json({ 
                success: false, 
                message: 'Invalid table number' 
            });
        }
        
        if (tableNum < 1 || tableNum > 10) {
            return res.status(400).json({ 
                success: false, 
                message: 'Table number must be between 1 and 10' 
            });
        }
        
        const total = parseInt(totalPeople);
        if (isNaN(total) || total < 1) {
            return res.status(400).json({ 
                success: false, 
                message: 'Total people must be at least 1' 
            });
        }
        
        // Check if table is already booked
        const existingBooking = await Booking.findOne({ 
            tableNumber: tableNum,
            status: 'confirmed'
        });
        
        if (existingBooking) {
            return res.status(400).json({ 
                success: false, 
                message: `Table ${tableNum} is already booked` 
            });
        }
        
        // Create new booking
        const newBooking = new Booking({
            name,
            mobile,
            tableNumber: tableNum,
            totalPeople: total
        });
        
        await newBooking.save();
        
        res.json({ 
            success: true, 
            message: `Table ${tableNum} booked successfully for ${name}`,
            booking: newBooking
        });
    } catch (error) {
        console.error("Booking error:", error);
        res.status(500).json({ 
            success: false, 
            message: 'An error occurred while processing your booking' 
        });
    }
});

// API endpoint to get all bookings
app.get("/api/all-bookings", async (req, res) => {
    try {
        const bookings = await Booking.find().sort({ bookingTime: -1 });
        res.json({ success: true, bookings });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Error fetching bookings' });
    }
});

// Start the server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));